Content
Sources: [sar cpu]
Parsers: [cpu sar]
Fields: [cpu]

Reference
Fields: [cpuidlpercent, cpuiowpercent, cpusyspercent, cpuusrpercent, mbody, timeampm]
